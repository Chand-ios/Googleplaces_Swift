//
//  AppDelegate.swift
//  GooglePlacesSearchController
//
//  Created by Dmitry Shmidt on 07/01/2015.
//  Copyright (c) 07/01/2015 Dmitry Shmidt. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        return true
    }

}
